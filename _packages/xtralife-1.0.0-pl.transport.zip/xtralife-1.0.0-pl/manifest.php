<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'This project is proprietary ownership of modmore, until the project is completed
and fully paid at which point the license below will go into effect, per project
agreement signed October 2nd, 2021.

- - - - -

The MIT License (MIT)

Copyright (c) 2021 modmore <support@modmore.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
',
    'readme' => 'XtraLife for MODX
---------------------

User integration for the XtraLife game platform. This package includes a custom MODX User type (xlUser)
and various other bits and pieces to allow managing XtraLife users from a MODX site.
',
    'changelog' => 'XtraLife 1.0.0-dev1
---------------------
Released on 2021-10-0

- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3c2318973f5ad570e0ab3e2e04fdc2aa',
      'native_key' => 'xtralife',
      'filename' => 'modNamespace/18ab95857bc1929e27391a5fa7d55d78.vehicle',
      'namespace' => 'xtralife',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '26b1e5f03833087eecd1c3c457bccb38',
      'native_key' => '26b1e5f03833087eecd1c3c457bccb38',
      'filename' => 'xPDOFileVehicle/f2cba7907e188e874ac7873c603b7579.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e3dc340cf4c87fd47a5b8e21e826b503',
      'native_key' => NULL,
      'filename' => 'modCategory/9bbe47e01a6a23a213bce02f9f6b2e84.vehicle',
      'namespace' => 'xtralife',
    ),
  ),
);
XtraLife for MODX
---------------------

User integration for the XtraLife game platform. This package includes a custom MODX User type (xlUser)
and various other bits and pieces to allow managing XtraLife users from a MODX site.

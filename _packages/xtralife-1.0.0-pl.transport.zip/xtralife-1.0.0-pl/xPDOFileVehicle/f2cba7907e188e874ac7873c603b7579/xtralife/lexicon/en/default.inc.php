<?php
$_lang['xtralife'] = 'XtraLife';

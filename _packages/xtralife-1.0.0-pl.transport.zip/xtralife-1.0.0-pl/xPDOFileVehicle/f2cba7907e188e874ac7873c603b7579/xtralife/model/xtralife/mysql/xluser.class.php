<?php
require_once strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/xluser.class.php';
/**
 * XtraLife user integration for MODX.
 *
 * Copyright 2021 by modmore
 *
 * @package xtralife
 * @license See core/components/xtralife/docs/license.txt
 */
class xlUser_mysql extends xlUser
{

}

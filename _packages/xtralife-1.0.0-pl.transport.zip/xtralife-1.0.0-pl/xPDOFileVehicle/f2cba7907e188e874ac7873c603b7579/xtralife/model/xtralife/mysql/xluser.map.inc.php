<?php
/**
 * XtraLife user integration for MODX.
 *
 * Copyright 2021 by modmore 
 *
 * @package xtralife
 * @license See core/components/xtralife/docs/license.txt
 */

$xpdo_meta_map['xlUser']= array (
  'package' => 'xtralife',
  'version' => '1.1',
  'extends' => 'modUser',
  'tableMeta' => 
  array (
    'engine' => 'InnoDB',
  ),
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
